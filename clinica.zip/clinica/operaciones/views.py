from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
from django import forms

# Create your views here.
def index(request):
    fecha = datetime.now()
    formatoFecha = fecha.strftime("%d-%m-%Y")
    formatoHora = fecha.strftime('%H:%M:%S')
    return render(request, "operaciones/index.html", {
        'fecha': formatoFecha,
        'hora': formatoHora
    })

def login(request):
    fecha = datetime.now()
    formatoFecha = fecha.strftime("%d-%m-%Y")
    formatoHora = fecha.strftime('%H:%M:%S')
    return render(request, "operaciones/login.html", {
        'fecha': formatoFecha,
        'hora': formatoHora
    })

def pedidos(request):
    return render(request, "operaciones/pedidos.html", {
        'pedidos': pedidos
    })

def turnos(request):
    return render(request, "operaciones/turnos.html", {
        'turnos': turnos
    })

def pacientes(request):
    return render(request, "operaciones/pacientes.html", {
        'pacientes': pacientes
    })







