from django.db import models
from datetime import datetime
import calendar

# Create your models here.
class Personal(models.Model):
    nombre = models.CharField(max_length = 64)
    apellido = models.CharField(max_length = 64)
    DNI = models.IntegerField()
    sexo = models.CharField(max_length = 20)
    fecha_nacimiento = models.DateField()
    Cargo = models.CharField(max_length = 64)
    fecha_ingreso = models.DateField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} ({self.Cargo})"

class Paciente(models.Model):
    nombre = models.CharField(max_length = 64)
    apellido = models.CharField(max_length = 64)
    DNI = models.IntegerField()
    sexo = models.CharField(max_length = 20)
    fecha_nacimiento = models.DateField()
    fecha_registro = models.DateField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} ({self.DNI})"

class Producto(models.Model):
    codigo = models.CharField(max_length=64)
    descripcion = models. CharField(max_length=100)
    inventario = models.IntegerField()
    precio = models.DecimalField(max_digits=20, decimal_places=2)

    def __str__(self):
        return f"{self.descripcion} ({self.codigo})"

class Turno(models.Model):
    turno = models.TimeField()

    def __str__(self):
        return f"{self.turno}"

class Medico(models.Model):
    nombre = models.CharField(max_length=64)
    apellido = models.CharField(max_length=64)
    DNI = models.IntegerField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} ({self.DNI})"

class Cita(models.Model):
    dia = models.DateField()
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE, related_name="pacientes")
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE, related_name="medico_cita")
    turno = models.ForeignKey(Turno, on_delete=models.CASCADE, related_name="turno_cita")

    def __str__(self):
        return f"Paciente: {self.paciente}/Turno: {self.turno}/Medico: {self.medico}"

class Historial(models.Model):
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE, related_name="paciente_hist")
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE, related_name="medico_hist")
    historial = models.FileField()
    fecha = models.DateField()

    def __str__(self):
        return f"Historial {self.paciente} {self.fecha}"

class Vendedor(models.Model):
    nombre = models.CharField(max_length=64)
    apellido = models.CharField(max_length=64)
    DNI = models.IntegerField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} ({self.DNI})"

class Pedido(models.Model):
    ESTADO_CHOICES = (
        ('pendiente', 'Pendiente'),
        ('pedido', 'Pedido'),
        ('finalizado', 'Finalizado'),
    )
    vendedor = models.ForeignKey(Vendedor, on_delete=models.CASCADE, related_name="vendedor")
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE, related_name="cliente")
    fecha = models.DateField()
    item1 = models.IntegerField()
    descripcion1 = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="descripcion_1")
    cantidad1 = models.IntegerField()
    item2 = models.IntegerField()
    descripcion2 = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="descripcion_2")
    cantidad2 = models.IntegerField()
    item3 = models.IntegerField()
    descripcion3 = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="descripcion_3")
    cantidad3 = models.IntegerField()
    item4 = models.IntegerField()
    descripcion4 = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="descripcion_4")
    cantidad4 = models.IntegerField()
    item5 = models.IntegerField()
    descripcion5 = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="descripcion_5")
    cantidad5 = models.IntegerField()
    Formula = models.CharField(max_length=64)
    Estado = models.CharField(max_length=20, choices=ESTADO_CHOICES)

    def __str__(self):
        return f"Pedido # {self.id}"
    















   

    
    
         








       


    

    

