from django.apps import AppConfig


class OperacionesConfig(AppConfig):
    name = 'operaciones'
