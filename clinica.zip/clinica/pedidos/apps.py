from django.apps import AppConfig


class PedidosConfig(AppConfig):
    name = 'pedidos'
